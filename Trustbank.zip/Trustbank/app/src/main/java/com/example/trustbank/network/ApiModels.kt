package com.example.trustbank.network

// These mirror the JSON shapes server.js actually sends/accepts — field
// names have to match exactly, since Gson maps JSON keys to data class
// property names by name, not by position.

data class ApiAccount(
    val id: Int,
    val name: String,
    val type: String,
    val balance: Double
)

data class ApiTransaction(
    val id: Int,
    val accountId: Int,
    val type: String,
    val amount: Double,
    val title: String,
    val date: Long,
    val note: String?,
    val linkedTransferId: Int?
)

data class NewAccountRequest(
    val name: String,
    val type: String,
    val balance: Double
)

data class NewTransactionRequest(
    val type: String,
    val amount: Double,
    val title: String,
    val note: String
)

data class TransferRequest(
    val fromAccountId: Int,
    val toAccountId: Int,
    val amount: Double,
    val note: String
)

data class TransferResponse(
    val outTransaction: ApiTransaction,
    val inTransaction: ApiTransaction
)
