package com.example.trustbank.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = Account::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("accountId")]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val accountId: Int,
    val type: TransactionType,
    val amount: Double,
    val title: String,
    val date: Long = System.currentTimeMillis(),
    val note: String = "",
    // Set only on TRANSFER_IN/TRANSFER_OUT rows — points at the sibling
    // row on the other account so a transfer can be shown/undone as one
    // logical unit even though it's stored as two rows.
    val linkedTransferId: Int? = null
)
