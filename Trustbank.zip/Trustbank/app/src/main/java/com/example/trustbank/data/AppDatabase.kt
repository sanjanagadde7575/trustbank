package com.example.trustbank.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.trustbank.security.SecurePassphraseProvider
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

/**
 * Same singleton pattern as SnapSpend's AppDatabase, with one addition:
 * openHelperFactory(SupportFactory(...)) swaps Room's default plain-
 * SQLite engine for SQLCipher, so the .db file this writes to disk is
 * encrypted with the passphrase from SecurePassphraseProvider. Nothing
 * about the DAOs, entities, or the rest of the app needs to know or care
 * that this happened — encryption is entirely a database-open-time
 * concern.
 */
@Database(entities = [Account::class, Transaction::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                SQLiteDatabase.loadLibs(context)

                val passphrase = SecurePassphraseProvider.getOrCreatePassphrase(context)
                val factory = SupportFactory(SQLiteDatabase.getBytes(passphrase))

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "trustbank_database"
                )
                    .openHelperFactory(factory)
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
