package com.example.trustbank.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom

/**
 * Produces the passphrase that unlocks the encrypted database, generating
 * a new random one the very first time the app runs.
 *
 * The passphrase itself never appears anywhere in source code as a fixed
 * string — that would defeat the whole point of encrypting the database.
 * Instead: 32 random bytes are generated once, hex-encoded, and stored
 * inside EncryptedSharedPreferences. EncryptedSharedPreferences' own
 * encryption key lives in the Android Keystore (hardware-backed on most
 * devices), so the passphrase is never written to disk in a directly
 * readable form.
 */
object SecurePassphraseProvider {
    private const val PREFS_NAME = "trustbank_secure_prefs"
    private const val KEY_DB_PASSPHRASE = "db_passphrase"

    fun getOrCreatePassphrase(context: Context): CharArray {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val prefs = EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        var passphrase = prefs.getString(KEY_DB_PASSPHRASE, null)
        if (passphrase == null) {
            val randomBytes = ByteArray(32)
            SecureRandom().nextBytes(randomBytes)
            passphrase = randomBytes.joinToString("") { "%02x".format(it) }
            prefs.edit().putString(KEY_DB_PASSPHRASE, passphrase).apply()
        }
        return passphrase.toCharArray()
    }
}
