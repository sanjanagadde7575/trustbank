package com.example.trustbank.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.trustbank.data.Account
import com.example.trustbank.data.AccountRepository
import com.example.trustbank.data.AccountType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountViewModel(private val repository: AccountRepository) : ViewModel() {

    val accounts: StateFlow<List<Account>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val netWorth: StateFlow<Double> = repository.netWorth
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addAccount(name: String, type: AccountType, initialBalance: Double = 0.0, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            repository.addAccount(name, type, initialBalance)
            onSaved()
        }
    }

    fun deleteAccount(account: Account) {
        viewModelScope.launch { repository.deleteAccount(account) }
    }

    /** Re-syncs every account's balance from the backend, ignored silently if unreachable. */
    fun refresh() {
        viewModelScope.launch { repository.refreshFromBackend() }
    }

    companion object {
        fun provideFactory(repository: AccountRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AccountViewModel(repository) as T
                }
            }
    }
}
