package com.example.trustbank.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.trustbank.data.Account

/**
 * The real home screen, shown only after LockScreen has unlocked. Net
 * worth on top (AccountViewModel.netWorth, one SQL SUM query), the list
 * of individual accounts below it, and a shortcut into the transfer flow.
 */
@Composable
fun AccountsOverviewScreen(
    accountViewModel: AccountViewModel,
    onAccountClick: (Int) -> Unit,
    onAddAccountClick: () -> Unit,
    onTransferClick: () -> Unit
) {
    val accounts by accountViewModel.accounts.collectAsState()
    val netWorth by accountViewModel.netWorth.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAddAccountClick) {
                Icon(Icons.Default.Add, contentDescription = "Add account")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text("TrustBank", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Net Worth", style = MaterialTheme.typography.titleMedium)
                    Text("$${"%.2f".format(netWorth)}", style = MaterialTheme.typography.headlineLarge)
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onTransferClick, modifier = Modifier.fillMaxWidth()) {
                Text("Transfer Between Accounts")
            }

            Spacer(Modifier.height(20.dp))
            Text("Your Accounts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            if (accounts.isEmpty()) {
                Text(
                    "No accounts yet — tap + to add your first one.",
                    style = MaterialTheme.typography.bodyLarge
                )
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(accounts, key = { it.id }) { account ->
                        AccountRow(account = account, onClick = { onAccountClick(account.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountRow(account: Account, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(account.name, style = MaterialTheme.typography.bodyLarge)
                Text(
                    account.type.name.lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text("$${"%.2f".format(account.balance)}", style = MaterialTheme.typography.titleMedium)
        }
    }
}
