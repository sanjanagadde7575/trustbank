package com.example.trustbank.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One bank account. Every Transaction belongs to exactly one Account via
 * accountId, and an Account's `balance` is the running total that gets
 * adjusted every time a transaction is added — the accounts overview
 * screen just reads this column directly rather than summing transactions
 * on every render.
 */
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: AccountType,
    val balance: Double = 0.0
)
