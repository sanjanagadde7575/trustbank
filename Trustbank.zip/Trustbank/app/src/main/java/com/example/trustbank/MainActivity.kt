package com.example.trustbank

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.trustbank.data.AccountRepository
import com.example.trustbank.data.AppDatabase
import com.example.trustbank.data.TransactionRepository
import com.example.trustbank.network.RetrofitClient
import com.example.trustbank.security.BiometricAuthHelper
import com.example.trustbank.ui.AccountDetailScreen
import com.example.trustbank.ui.AccountViewModel
import com.example.trustbank.ui.AccountsOverviewScreen
import com.example.trustbank.ui.AddAccountScreen
import com.example.trustbank.ui.LockScreen
import com.example.trustbank.ui.TransactionViewModel
import com.example.trustbank.ui.TransferScreen
import com.example.trustbank.ui.theme.TrustbankTheme

/**
 * Entry point. Same overall shape as SnapSpend's MainActivity — build the
 * dependencies (database + repositories), then hand off to a NavHost —
 * with one addition up front: nothing in the NavHost is reachable until
 * BiometricAuthHelper confirms who's holding the phone.
 *
 * Extends FragmentActivity rather than ComponentActivity because
 * BiometricPrompt needs a FragmentActivity to host the system prompt.
 * FragmentActivity is itself a ComponentActivity, so setContent works
 * exactly the same as before.
 */
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(this)
        val accountRepository = AccountRepository(database.accountDao(), RetrofitClient.apiService)
        val transactionRepository = TransactionRepository(database.transactionDao(), accountRepository, RetrofitClient.apiService)

        setContent {
            TrustbankTheme {
                val accountViewModel: AccountViewModel = viewModel(
                    factory = AccountViewModel.provideFactory(accountRepository)
                )
                val transactionViewModel: TransactionViewModel = viewModel(
                    factory = TransactionViewModel.provideFactory(transactionRepository)
                )

                var isUnlocked by remember { mutableStateOf(false) }
                var authError by remember { mutableStateOf<String?>(null) }
                val biometricAvailable = remember { BiometricAuthHelper.isAvailable(this@MainActivity) }

                LaunchedEffect(isUnlocked) {
                    if (isUnlocked) {
                        accountViewModel.refresh()
                    }
                }

                if (!isUnlocked) {
                    LockScreen(
                        isBiometricAvailable = biometricAvailable,
                        errorMessage = authError,
                        onUnlockClick = {
                            authError = null
                            BiometricAuthHelper.authenticate(
                                activity = this@MainActivity,
                                onSuccess = { isUnlocked = true },
                                onError = { message -> authError = message }
                            )
                        }
                    )
                } else {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = "overview") {

                        composable("overview") {
                            AccountsOverviewScreen(
                                accountViewModel = accountViewModel,
                                onAccountClick = { accountId -> navController.navigate("accountDetail/$accountId") },
                                onAddAccountClick = { navController.navigate("addAccount") },
                                onTransferClick = { navController.navigate("transfer") }
                            )
                        }

                        composable(
                            route = "accountDetail/{accountId}",
                            arguments = listOf(navArgument("accountId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val accountId = backStackEntry.arguments?.getInt("accountId") ?: return@composable
                            AccountDetailScreen(
                                accountId = accountId,
                                accountViewModel = accountViewModel,
                                transactionViewModel = transactionViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("addAccount") {
                            AddAccountScreen(
                                onSave = { name, type, initialBalance ->
                                    accountViewModel.addAccount(name, type, initialBalance) {
                                        navController.popBackStack()
                                    }
                                },
                                onCancel = { navController.popBackStack() }
                            )
                        }

                        composable("transfer") {
                            TransferScreen(
                                accountViewModel = accountViewModel,
                                transactionViewModel = transactionViewModel,
                                onDone = { navController.popBackStack() },
                                onCancel = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
