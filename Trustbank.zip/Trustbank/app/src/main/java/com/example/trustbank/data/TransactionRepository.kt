package com.example.trustbank.data

import android.util.Log
import com.example.trustbank.network.ApiTransaction
import com.example.trustbank.network.NewTransactionRequest
import com.example.trustbank.network.TransferRequest
import com.example.trustbank.network.TrustBankApiService
import kotlinx.coroutines.flow.Flow

/**
 * Same network-first-with-local-fallback shape as AccountRepository. A
 * successful deposit/withdrawal/transfer caches the server's own copy of
 * the new transaction row(s) and then re-syncs account balances from the
 * backend (rather than adjusting them by hand locally), so there's one
 * place — the server — deciding what the "real" balance is whenever it's
 * reachable.
 */
class TransactionRepository(
    private val transactionDao: TransactionDao,
    private val accountRepository: AccountRepository,
    private val apiService: TrustBankApiService
) {

    val recentTransactions: Flow<List<Transaction>> = transactionDao.getRecentTransactions()

    fun transactionsForAccount(accountId: Int): Flow<List<Transaction>> =
        transactionDao.getTransactionsForAccount(accountId)

    suspend fun addDeposit(accountId: Int, amount: Double, title: String, note: String = "") {
        addSingleAccountTransaction(accountId, "DEPOSIT", amount, title, note)
    }

    suspend fun addWithdrawal(accountId: Int, amount: Double, title: String, note: String = "") {
        addSingleAccountTransaction(accountId, "WITHDRAWAL", amount, title, note)
    }

    private suspend fun addSingleAccountTransaction(
        accountId: Int,
        type: String,
        amount: Double,
        title: String,
        note: String
    ) {
        try {
            val apiTransaction = apiService.addTransaction(
                accountId,
                NewTransactionRequest(type = type, amount = amount, title = title, note = note)
            )
            transactionDao.insert(apiTransaction.toEntity())
            accountRepository.refreshFromBackend()
            return
        } catch (e: Exception) {
            Log.e("TrustBankSync", "addSingleAccountTransaction failed, falling back to local-only", e)
        }

        transactionDao.insert(
            Transaction(
                accountId = accountId,
                type = TransactionType.valueOf(type),
                amount = amount,
                title = title,
                note = note
            )
        )
        accountRepository.adjustBalance(accountId, if (type == "DEPOSIT") amount else -amount)
    }

    suspend fun transfer(fromAccountId: Int, toAccountId: Int, amount: Double, note: String = "") {
        try {
            val response = apiService.transfer(TransferRequest(fromAccountId, toAccountId, amount, note))
            transactionDao.insert(response.outTransaction.toEntity())
            transactionDao.insert(response.inTransaction.toEntity())
            accountRepository.refreshFromBackend()
            return
        } catch (e: Exception) {
            Log.e("TrustBankSync", "transfer failed, falling back to local-only", e)
        }

        val outId = transactionDao.insert(
            Transaction(accountId = fromAccountId, type = TransactionType.TRANSFER_OUT, amount = amount, title = "Transfer out", note = note)
        )
        val inId = transactionDao.insert(
            Transaction(
                accountId = toAccountId,
                type = TransactionType.TRANSFER_IN,
                amount = amount,
                title = "Transfer in",
                note = note,
                linkedTransferId = outId.toInt()
            )
        )
        transactionDao.getTransactionById(outId.toInt())?.let { outRow ->
            transactionDao.update(outRow.copy(linkedTransferId = inId.toInt()))
        }
        accountRepository.adjustBalance(fromAccountId, -amount)
        accountRepository.adjustBalance(toAccountId, amount)
    }

    suspend fun deleteTransaction(transaction: Transaction) = transactionDao.delete(transaction)

    /** Pulls one account's transaction history fresh from the backend into the local cache. */
    suspend fun refreshTransactionsForAccount(accountId: Int) {
        val apiTransactions = try {
            apiService.getTransactionsForAccount(accountId)
        } catch (e: Exception) {
            Log.e("TrustBankSync", "refreshTransactionsForAccount failed", e)
            return
        }
        apiTransactions.forEach { upsert(it) }
    }

    private suspend fun upsert(apiTransaction: ApiTransaction) {
        val existing = transactionDao.getTransactionById(apiTransaction.id)
        val transaction = apiTransaction.toEntity()
        if (existing == null) transactionDao.insert(transaction) else transactionDao.update(transaction)
    }
}

private fun ApiTransaction.toEntity(): Transaction =
    Transaction(
        id = id,
        accountId = accountId,
        type = TransactionType.valueOf(type),
        amount = amount,
        title = title,
        date = date,
        note = note ?: "",
        linkedTransferId = linkedTransferId
    )
