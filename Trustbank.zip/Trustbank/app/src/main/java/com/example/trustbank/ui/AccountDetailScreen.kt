package com.example.trustbank.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.trustbank.data.Transaction
import com.example.trustbank.data.TransactionType

/**
 * One account's balance, type, and full transaction history, plus a "+"
 * that opens a small dialog for logging a deposit or withdrawal directly
 * on this account (transfers between accounts have their own screen,
 * Step 13, since those need a second account picked).
 */
@Composable
fun AccountDetailScreen(
    accountId: Int,
    accountViewModel: AccountViewModel,
    transactionViewModel: TransactionViewModel,
    onBack: () -> Unit
) {
    val accounts by accountViewModel.accounts.collectAsState()
    val account = accounts.find { it.id == accountId }
    val transactions by transactionViewModel.transactionsForAccount(accountId).collectAsState(initial = emptyList())

    LaunchedEffect(accountId) {
        transactionViewModel.refreshTransactionsForAccount(accountId)
    }

    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add transaction")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }

            if (account == null) {
                Text("Account not found")
            } else {
                Text(account.name, style = MaterialTheme.typography.headlineMedium)
                Text(
                    account.type.name.lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text("$${"%.2f".format(account.balance)}", style = MaterialTheme.typography.displaySmall)

                Spacer(Modifier.height(20.dp))
                Text("Transaction History", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                if (transactions.isEmpty()) {
                    Text("No transactions yet on this account.", style = MaterialTheme.typography.bodyLarge)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(transactions, key = { it.id }) { tx -> TransactionRow(tx) }
                    }
                }

                if (showAddDialog) {
                    AddTransactionDialog(
                        onDismiss = { showAddDialog = false },
                        onSave = { type, amount, title ->
                            when (type) {
                                TransactionType.DEPOSIT -> transactionViewModel.addDeposit(account.id, amount, title)
                                TransactionType.WITHDRAWAL -> transactionViewModel.addWithdrawal(account.id, amount, title)
                                else -> {}
                            }
                            showAddDialog = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TransactionRow(transaction: Transaction) {
    val isPositive = transaction.type == TransactionType.DEPOSIT || transaction.type == TransactionType.TRANSFER_IN
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(transaction.title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    transaction.type.name.lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (isPositive) "+$" else "-$") + "%.2f".format(transaction.amount),
                color = if (isPositive) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
private fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onSave: (TransactionType, Double, String) -> Unit
) {
    var type by remember { mutableStateOf(TransactionType.DEPOSIT) }
    var amountText by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Transaction") },
        text = {
            Column {
                Row {
                    FilterChip(
                        selected = type == TransactionType.DEPOSIT,
                        onClick = { type = TransactionType.DEPOSIT },
                        label = { Text("Deposit") }
                    )
                    Spacer(Modifier.width(8.dp))
                    FilterChip(
                        selected = type == TransactionType.WITHDRAWAL,
                        onClick = { type = TransactionType.WITHDRAWAL },
                        label = { Text("Withdrawal") }
                    )
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = amountText.toDoubleOrNull() ?: 0.0
                if (amount > 0) {
                    onSave(type, amount, title.ifBlank { type.name.lowercase().replaceFirstChar { it.uppercase() } })
                }
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
