package com.example.trustbank.ui.theme

import androidx.compose.ui.graphics.Color

// Navy + gold: distinct from EchoNotes' orange and SnapSpend's green, and
// closer to what an actual bank's branding tends to look like.
val TrustBlue80 = Color(0xFFB4C8EA)
val NeutralSlate80 = Color(0xFFC8CCD2)
val GoldAccent80 = Color(0xFFE8D6A3)

val TrustBlue40 = Color(0xFF1B3A6B)
val NeutralSlate40 = Color(0xFF48505C)
val GoldAccent40 = Color(0xFF9C7A1E)
