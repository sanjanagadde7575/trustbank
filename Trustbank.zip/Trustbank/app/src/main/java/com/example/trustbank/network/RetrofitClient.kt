package com.example.trustbank.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * 10.0.2.2 is the Android emulator's special address for "the computer
 * running the emulator" — it is NOT a real internet address, so this only
 * works while testing on the emulator with TrustBankServer running on
 * this same Mac. A physical device on the same Wi-Fi would need the
 * Mac's actual LAN IP instead.
 */
object RetrofitClient {
    private const val BASE_URL = "http://10.0.2.2:4000/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    val apiService: TrustBankApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TrustBankApiService::class.java)
    }
}
