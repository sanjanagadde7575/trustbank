package com.example.trustbank.network

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface TrustBankApiService {

    @GET("accounts")
    suspend fun getAccounts(): List<ApiAccount>

    @POST("accounts")
    suspend fun createAccount(@Body request: NewAccountRequest): ApiAccount

    @DELETE("accounts/{id}")
    suspend fun deleteAccount(@Path("id") id: Int)

    @GET("accounts/{id}/transactions")
    suspend fun getTransactionsForAccount(@Path("id") id: Int): List<ApiTransaction>

    @POST("accounts/{id}/transactions")
    suspend fun addTransaction(@Path("id") id: Int, @Body request: NewTransactionRequest): ApiTransaction

    @GET("transactions")
    suspend fun getRecentTransactions(@Query("limit") limit: Int = 20): List<ApiTransaction>

    @POST("transfer")
    suspend fun transfer(@Body request: TransferRequest): TransferResponse
}
