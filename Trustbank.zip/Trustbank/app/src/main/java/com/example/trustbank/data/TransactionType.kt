package com.example.trustbank.data

/**
 * DEPOSIT / WITHDRAWAL cover simple money-in / money-out on one account.
 * A transfer between two of your own accounts is recorded as a *pair* of
 * rows — a TRANSFER_OUT on the source account and a TRANSFER_IN on the
 * destination — linked by linkedTransferId on the Transaction entity.
 * This is the same idea real ledgers use (every movement has two sides)
 * instead of a single row that silently touches two tables at once.
 */
enum class TransactionType { DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT }
