package com.example.trustbank.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.trustbank.data.Transaction
import com.example.trustbank.data.TransactionRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TransactionViewModel(private val repository: TransactionRepository) : ViewModel() {

    val recentTransactions: StateFlow<List<Transaction>> = repository.recentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Per-account history is only needed once you're actually looking at
    // that account's detail screen, so this hands back the raw Flow for
    // the screen to collect itself, rather than pre-building a StateFlow
    // for every account up front.
    fun transactionsForAccount(accountId: Int): Flow<List<Transaction>> =
        repository.transactionsForAccount(accountId)

    fun addDeposit(accountId: Int, amount: Double, title: String, note: String = "", onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            repository.addDeposit(accountId, amount, title, note)
            onSaved()
        }
    }

    fun addWithdrawal(accountId: Int, amount: Double, title: String, note: String = "", onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            repository.addWithdrawal(accountId, amount, title, note)
            onSaved()
        }
    }

    fun transfer(fromAccountId: Int, toAccountId: Int, amount: Double, note: String = "", onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            repository.transfer(fromAccountId, toAccountId, amount, note)
            onSaved()
        }
    }

    /** Re-syncs one account's transaction history from the backend, called when its detail screen opens. */
    fun refreshTransactionsForAccount(accountId: Int) {
        viewModelScope.launch { repository.refreshTransactionsForAccount(accountId) }
    }

    companion object {
        fun provideFactory(repository: TransactionRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return TransactionViewModel(repository) as T
                }
            }
    }
}
