package com.example.trustbank.data

/**
 * What kind of account this is. Kept deliberately small (three kinds) so
 * the accounts overview screen stays meaningful without turning this into
 * a real bank's full chart of accounts.
 */
enum class AccountType { CHECKING, SAVINGS, CREDIT }
