package com.example.trustbank.data

import androidx.room.TypeConverter

/**
 * Room only knows how to store primitives and Strings natively, so both
 * enums used by the entities need a converter — same pattern as
 * SnapSpend's TransactionType converter, just one for each enum here.
 */
class Converters {
    @TypeConverter
    fun fromAccountType(value: AccountType): String = value.name

    @TypeConverter
    fun toAccountType(value: String): AccountType = AccountType.valueOf(value)

    @TypeConverter
    fun fromTransactionType(value: TransactionType): String = value.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType = TransactionType.valueOf(value)
}
