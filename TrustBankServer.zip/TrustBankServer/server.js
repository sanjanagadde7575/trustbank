// TrustBank backend — a small Express API backed by SQLite, mirroring the
// same Account/Transaction shape as the Android app's Room database. The
// Android app treats this server as the source of truth and caches its
// responses locally, but this file has no idea the Android app is
// encrypted or biometric-locked — that's entirely a phone-side concern.

const express = require('express');
const cors = require('cors');
const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const db = new DatabaseSync(path.join(__dirname, 'trustbank.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    balance REAL NOT NULL DEFAULT 0
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    accountId INTEGER NOT NULL,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    title TEXT NOT NULL,
    date INTEGER NOT NULL,
    note TEXT DEFAULT '',
    linkedTransferId INTEGER,
    FOREIGN KEY (accountId) REFERENCES accounts(id) ON DELETE CASCADE
  );
`);

function adjustBalance(accountId, delta) {
  db.prepare('UPDATE accounts SET balance = balance + ? WHERE id = ?').run(delta, accountId);
}

// ---------------- Accounts ----------------

app.get('/accounts', (req, res) => {
  const rows = db.prepare('SELECT * FROM accounts ORDER BY id ASC').all();
  res.json(rows);
});

app.post('/accounts', (req, res) => {
  const { name, type, balance } = req.body;
  if (!name || !type) {
    return res.status(400).json({ error: 'name and type are required' });
  }
  const info = db
    .prepare('INSERT INTO accounts (name, type, balance) VALUES (?, ?, ?)')
    .run(name, type, balance ?? 0);
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(account);
});

app.get('/accounts/:id', (req, res) => {
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(Number(req.params.id));
  if (!account) return res.status(404).json({ error: 'not found' });
  res.json(account);
});

app.delete('/accounts/:id', (req, res) => {
  db.prepare('DELETE FROM accounts WHERE id = ?').run(Number(req.params.id));
  res.status(204).send();
});

// ---------------- Transactions ----------------

app.get('/accounts/:id/transactions', (req, res) => {
  const rows = db
    .prepare('SELECT * FROM transactions WHERE accountId = ? ORDER BY date DESC')
    .all(Number(req.params.id));
  res.json(rows);
});

app.get('/transactions', (req, res) => {
  const limit = Number(req.query.limit) || 20;
  const rows = db.prepare('SELECT * FROM transactions ORDER BY date DESC LIMIT ?').all(limit);
  res.json(rows);
});

// Deposit or withdrawal on a single account.
app.post('/accounts/:id/transactions', (req, res) => {
  const accountId = Number(req.params.id);
  const { type, amount, title, note } = req.body;

  if (!['DEPOSIT', 'WITHDRAWAL'].includes(type)) {
    return res.status(400).json({ error: 'type must be DEPOSIT or WITHDRAWAL' });
  }
  if (!amount || amount <= 0) {
    return res.status(400).json({ error: 'amount must be greater than 0' });
  }

  const info = db
    .prepare('INSERT INTO transactions (accountId, type, amount, title, date, note) VALUES (?, ?, ?, ?, ?, ?)')
    .run(accountId, type, amount, title || type, Date.now(), note || '');

  adjustBalance(accountId, type === 'DEPOSIT' ? amount : -amount);

  const transaction = db.prepare('SELECT * FROM transactions WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(transaction);
});

// Transfer between two accounts — same linked-pair-of-rows ledger pattern
// as TransactionRepository.transfer() on the Android side.
app.post('/transfer', (req, res) => {
  const { fromAccountId, toAccountId, amount, note } = req.body;

  if (fromAccountId === toAccountId) {
    return res.status(400).json({ error: 'choose two different accounts' });
  }
  if (!amount || amount <= 0) {
    return res.status(400).json({ error: 'amount must be greater than 0' });
  }

  const insert = db.prepare(
    'INSERT INTO transactions (accountId, type, amount, title, date, note, linkedTransferId) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );

  const outInfo = insert.run(fromAccountId, 'TRANSFER_OUT', amount, 'Transfer out', Date.now(), note || '', null);
  const inInfo = insert.run(toAccountId, 'TRANSFER_IN', amount, 'Transfer in', Date.now(), note || '', outInfo.lastInsertRowid);
  db.prepare('UPDATE transactions SET linkedTransferId = ? WHERE id = ?').run(inInfo.lastInsertRowid, outInfo.lastInsertRowid);

  adjustBalance(fromAccountId, -amount);
  adjustBalance(toAccountId, amount);

  const outTransaction = db.prepare('SELECT * FROM transactions WHERE id = ?').get(outInfo.lastInsertRowid);
  const inTransaction = db.prepare('SELECT * FROM transactions WHERE id = ?').get(inInfo.lastInsertRowid);
  res.status(201).json({ outTransaction, inTransaction });
});

const PORT = 4000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`TrustBank backend listening on http://localhost:${PORT}`);
});
